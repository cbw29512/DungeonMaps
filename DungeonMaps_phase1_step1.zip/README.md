# DungeonMaps

A local LAN battle map + token tool for D&D 5e and Call of Cthulhu. Simple, fast, no bloat.
See `BattleMap_Schema.md` (the v4 spec) for the full design.

## Status: Phase 1 — Step 1 (foundation only)

This commit is the server skeleton. **No UI, no game logic yet** — on purpose. It exists to
prove the foundation boots and the data layer is correct before anything is built on top.

What's here:
- Node HTTP server with a `/health` check.
- Local SQLite database (Node's built-in `node:sqlite` — no native build tools needed) that
  auto-creates the full v4 schema on first run.
- A WebSocket sync channel speaking the `SyncAdapter` protocol (the seam that lets Phase 2 go
  online without rewriting the client).

## Prerequisites

- Node.js 22.5+ (you have 24.16.0).

## Run

```powershell
npm install
npm start
```

Then open <http://localhost:5174/health> in a browser. You should see JSON like:

```json
{ "ok": true, "service": "dungeonmaps", "tables": [ ...8 tables... ] }
```

The database file is created at `data/dungeonmaps.db` (gitignored — it's machine-local state).
Stop the server with Ctrl-C.

## Checkpoint for this step

1. `npm install` completes with no compilation errors.
2. `npm start` prints the DB path, the 8 table names, and the listening URLs.
3. `/health` responds with `ok: true` and lists 8 tables.

That's the whole step. Next step is reviewed before any UI is added.

## Not in Phase 1

Dice, chat, character sheets, HP/health, initiative tracker, marketplace, dynamic lighting,
line-of-sight fog, public hosting, Supabase, accounts.
